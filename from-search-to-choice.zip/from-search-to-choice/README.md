# From Search to Choice

An animated summary of our customer experience audit of Clas Ohlson in Oslo and Strømmen.
Course: MST 0220 Customer Experience Management, BI Norwegian Business School, autumn 2026.

[![From Search to Choice: cover](cover.png)](From_Search_to_Choice.mp4)

▶ **[Watch the film (From_Search_to_Choice.mp4)](From_Search_to_Choice.mp4)** · 3:22

## What the film covers

The film follows one customer journey, from searching for a product online to making an informed choice in store, and shows where that journey breaks down.

| Time | Scene | Content |
|---|---|---|
| 0:00 | Introduction | Title and research question |
| 0:05 | Primary research | 6 visits, 4 stores, 3 dates, 74 reviews |
| 0:15 | The journey | The path from online search to an informed choice |
| 0:27 | 19 October | The three visits on the first day |
| 0:43 | 26 Oct and 3 Nov | The three later visits |
| 1:03 | Who moved first | Who started contact, and the recorded wait |
| 1:16 | Three and three | Three visits ended with a suitable product, three did not |
| 1:29 | 74 reviews | The Google review sample and its limits |
| 1:41 | Access vs. advice | Access to help mostly negative, quality of advice mostly positive |
| 1:53 | Four lenses | The theory lenses and what the evidence supports |
| 2:11 | The problem | Two gates: getting help, and advice that helps you choose |
| 2:26 | Recommendations | Three proposed improvements |
| 2:45 | How to test it | A pilot in selected stores and five measures |
| 2:55 | Sustainability | Environmental, social and financial effects |
| 3:11 | Conclusion | Closing message, course and sources |

## Data behind it

- **6 mystery-shopping visits** across **4 stores**: Torggata, Stenersgata 2, Strømmen Storsenter and Storo Storsenter.
- **Visit dates:** 19 Oct 2026 (3 visits), 26 Oct 2026 (2 visits), 3 Nov 2026 (1 visit). No purchases were made.
- **74 Google reviews**, coded systematically as secondary data.
- **Key finding:** in 0 of 6 visits did an employee approach the customer first.

## Repository contents

| Path | What it is |
|---|---|
| `From_Search_to_Choice.mp4` | The finished film |
| `cover.png` | Cover image (1920 × 1080) |
| `source/` | The film's scene code, styles and sound score, for reference |

The code in `source/` was written for an animation player and does not run on its own.
