// The store's fixtures. Pegboard ground and vignette live in base.css; these build the rails, signs and tags every scene hangs things on.
window.W = {
  // A hanging sign on two cords from the ceiling. Its group pivots at the ceiling point (cx, -160) so a scene swings it by one rotate.
  sign(cls, cx, y, w, h, size, text) {
    const x = cx - w / 2;
    return '<div class="' + cls + '" style="position:absolute;left:0;top:0;width:1920px;height:1080px;transform-origin:' + cx + 'px -160px">' +
      '<div class="box" style="left:' + (x + w * 0.18) + 'px;top:0;width:4px;height:' + y + 'px;background:var(--rail)"></div>' +
      '<div class="box" style="left:' + (x + w * 0.82 - 4) + 'px;top:0;width:4px;height:' + y + 'px;background:var(--rail)"></div>' +
      '<div class="sign" style="left:' + x + 'px;top:' + y + 'px;width:' + w + 'px;min-height:' + h + 'px;font-size:' + size + 'px">' + text + '</div></div>';
  },
  // A shelf rail with two wall brackets.
  rail(cls, x, y, w) {
    return '<div class="rail ' + cls + '" style="left:' + x + 'px;top:' + y + 'px;width:' + w + 'px"></div>' +
      '<div class="box" style="left:' + (x + 30) + 'px;top:' + (y + 10) + 'px;width:10px;height:26px;border-radius:3px;background:var(--rail)"></div>' +
      '<div class="box" style="left:' + (x + w - 40) + 'px;top:' + (y + 10) + 'px;width:10px;height:26px;border-radius:3px;background:var(--rail)"></div>';
  },
  // The three observation dates on one line; the active ones lit.
  dates(cls, active) {
    const d = [['19 Oct 2026', '3 visits'], ['26 Oct 2026', '2 visits'], ['3 Nov 2026', '1 visit']];
    return '<div class="' + cls + '" style="position:absolute;left:140px;top:70px;width:1640px;height:90px">' +
      '<div class="box" style="left:10px;top:21px;width:1100px;height:4px;background:var(--rail)"></div>' +
      d.map((x, i) => { const on = active.indexOf(i) >= 0; return '<div class="box" style="left:' + (i * 520) + 'px;top:0;display:flex;gap:16px;align-items:flex-start">' +
        '<div style="width:28px;height:28px;margin-top:9px;border-radius:50%;box-sizing:border-box;border:4px solid ' + (on ? 'var(--main)' : 'var(--rail)') + ';background:' + (on ? 'var(--main)' : 'var(--ground)') + '"></div>' +
        '<div style="display:flex;flex-direction:column;gap:4px;padding:0 10px;background:var(--ground)"><span class="mono" style="font-size:28px;color:' + (on ? 'var(--main)' : 'var(--dim)') + '">' + x[0] + '</span><span class="mono dim" style="font-size:20px">' + x[1] + '</span></div></div>'; }).join('') + '</div>';
  },
  // An outcome stamp: yellow for a suitable product found, coral for not resolved.
  stamp(cls, ok, text) {
    return '<div class="tag ' + (ok ? '' : 'hot ') + cls + '" style="position:relative;display:inline-block;padding:10px 46px 10px 18px;align-self:flex-start"><span class="line sm" style="font-size:34px">' + text + '</span></div>';
  },
  // Hang an element: it drops onto its rail at a, overshoots, swings out and keeps a faint sway.
  hang(el, t, a, i, drop) {
    const p = kit.eob(kit.seg(t, a, a + 0.55), 1.7), since = Math.max(0, t - a - 0.55);
    const sw = kit.lerp(-8, 0, p) + 2.6 * Math.exp(-since * 1.8) * Math.sin(since * 8) + 0.45 * Math.sin(t * 1.3 + i * 1.7);
    el.style.opacity = Math.min(1, kit.seg(t, a, a + 0.12));
    el.style.transform = 'translateY(' + kit.lerp(-(drop || 90), 0, p) + 'px) rotate(' + sw.toFixed(2) + 'deg)';
  },
  // A slow push on a layer, so no frame is ever frozen.
  push(el, t, dur, from, to) {
    el.style.transform = 'scale(' + kit.lerp(from || 1, to || 1.025, kit.eio(kit.seg(t, 0, dur))) + ')';
  },
};
