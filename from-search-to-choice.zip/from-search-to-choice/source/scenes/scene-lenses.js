const { seg, eo, eio, eob, lerp, TextFx } = kit;
const L = [
  ['Journey continuity', 'Lemon & Verhoef (2016)', 'The website told customers where a product was, not which one suited them.', 'MS1, MS2', ''],
  ['Value creation and participation', 'Grönroos & Voima (2013) · Dong & Sivakumar (2017)', 'Advice built on the customer’s own context created confidence. Absent or postponed advice left the task unresolved.', 'MS1, MS3, MS4', ''],
  ['Service gaps and blueprinting', 'Parasuraman et al. (1985) · Bitner et al. (2008)', 'Engagement, routing of requests and shelf information mark where to look. The internal cause is not yet known.', 'MS1–MS3', ''],
  ['Customer centricity', 'Shah et al. (2006)', 'Measure whether advice-seeking customers leave with a clear next step, not only product availability.', 'Implication', 'ink']
];
kit.scene('lenses', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="lenses-cam" style="position:absolute;inset:0;transform-origin:960px 560px">' +
      '<div class="words" style="left:140px;top:80px;width:1640px;gap:14px"><p class="eyebrow">Theoretical analysis</p><h2 class="line md lenses-line">Four lenses on the same evidence</h2></div>' +
      W.rail('lenses-rail', 120, 288, 1680) +
      L.map((c, i) => '<div class="tag ' + c[4] + ' lenses-c" style="left:' + (140 + i * 415) + 'px;top:314px;width:395px;min-height:470px;transform-origin:197px -14px">' +
        '<div style="display:flex;flex-direction:column;gap:14px"><span class="mono" style="font-size:20px;line-height:1.35">' + c[1] + '</span>' +
        '<span class="line" style="font-size:54px;line-height:1">' + c[0] + '</span>' +
        '<span style="font-size:27px;line-height:1.32">' + c[2] + '</span>' +
        '<span class="mono" style="font-size:20px;font-weight:700">' + c[3] + '</span></div></div>').join('') +
      '<div class="words" style="left:140px;top:880px;width:1640px"><p class="line sm lenses-a">The expertise exists. Access to it is inconsistent.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.lenses-cam'), line: kit.stage.querySelector('.lenses-line'), rail: kit.stage.querySelector('.lenses-rail'), cards: all('.lenses-c'), a: kit.stage.querySelector('.lenses-a') });
  },
  render(t) {
    W.push(this.cam, t, 18, 1, 1.02);
    TextFx.fadeFromRight(this.line, t, 0.1);
    this.rail.style.transform = 'scaleX(' + eo(seg(t, 0.4, 1.0)) + ')';
    this.cards.forEach((el, i) => W.hang(el, t, 1.2 + i * 3.0, i, 120));
    TextFx.fadeFromRight(this.a, t, 11.6);
  },
});
