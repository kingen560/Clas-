const { seg, eo, eio, eob, lerp, TextFx } = kit;
const C = [
  ['Environmental', 'Fewer incompatible accessories and needless replacements, such as the right brush head for a toothbrush already owned (MS6). Fewer repeat trips just to get advice.', ''],
  ['Social', 'Easier access for customers who find technical products hard, and no need to repeat themselves after a handover. Staff take on more, alongside checkout and restocking.', 'ink'],
  ['Financial', 'Fewer unsuitable purchases and avoidable returns, weighed against the time for handovers, training and keeping product information precise.', '']
];
kit.scene('sustain', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="sustain-cam" style="position:absolute;inset:0;transform-origin:960px 560px">' +
      '<div class="words" style="left:140px;top:80px;width:1640px;gap:14px"><p class="eyebrow">Sustainability · possible effects, not measured</p><h2 class="line md sustain-line">Who benefits, and who bears the cost?</h2><p class="mono dim" style="font-size:22px">After Carlborg et al. (2024)</p></div>' +
      W.rail('sustain-rail', 120, 318, 1680) +
      C.map((c, i) => '<div class="tag ' + c[2] + ' sustain-c" style="left:' + (140 + i * 560) + 'px;top:344px;width:520px;min-height:420px;transform-origin:260px -14px">' +
        '<div style="display:flex;flex-direction:column;gap:18px"><span class="line" style="font-size:68px;line-height:1">' + c[0] + '</span>' +
        '<span style="font-size:30px;line-height:1.34">' + c[1] + '</span></div></div>').join('') +
      '<div class="words" style="left:140px;top:850px;width:1500px"><p class="sub sustain-b">The visits ended at product choice, so effects on returns, repeat trips and product lifetimes remain to be tested in the pilot.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.sustain-cam'), line: kit.stage.querySelector('.sustain-line'), rail: kit.stage.querySelector('.sustain-rail'), cards: all('.sustain-c'), b: kit.stage.querySelector('.sustain-b') });
  },
  render(t) {
    W.push(this.cam, t, 16, 1, 1.02);
    TextFx.fadeFromRight(this.line, t, 0.1);
    this.rail.style.transform = 'scaleX(' + eo(seg(t, 0.4, 1.0)) + ')';
    this.cards.forEach((el, i) => W.hang(el, t, 1.2 + i * 3.0, i, 120));
    const b = eo(seg(t, 10.6, 11.2));
    this.b.style.opacity = b; this.b.style.transform = 'translateX(' + lerp(26, 0, b) + 'px)';
  },
});
