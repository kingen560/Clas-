const { seg, eo, eio, eob, lerp, TextFx } = kit;
const ROWS = [['Access to assistance', 17, 8, '68%', 'negative', true], ['Quality of advice', 9, 40, '82%', 'positive', false]];
kit.scene('split', {
  init(kit) {
    const W0 = 1640;
    const row = (r, i) => { const n = r[1] + r[2], wn = Math.round(W0 * r[1] / n), y = 300 + i * 270;
      return '<div class="box" style="left:140px;top:' + y + 'px;width:' + W0 + 'px;display:flex;justify-content:space-between;align-items:flex-end"><span class="line sm" style="font-size:60px">' + r[0] + '</span>' +
        '<span class="split-p" style="display:flex;align-items:baseline;gap:14px"><span class="line num ' + (r[5] ? 'hot' : 'gold') + '" style="font-size:110px;line-height:.9">' + r[3] + '</span><span class="line sm" style="font-size:44px">' + r[4] + '</span></span></div>' +
        '<div class="box" style="left:140px;top:' + (y + 118) + 'px;width:' + W0 + 'px;height:96px;border-radius:10px;overflow:hidden;background:color-mix(in srgb, var(--second) 8%, transparent)">' +
        '<div class="box split-neg" style="left:0;top:0;width:' + (wn - 3) + 'px;height:96px;background:var(--accent);transform-origin:0 50%"></div>' +
        '<div class="box split-pos" style="left:' + wn + 'px;top:0;width:' + (W0 - wn) + 'px;height:96px;background:var(--main);transform-origin:0 50%"></div>' +
        '<span class="box mono split-l" style="left:24px;top:30px;font-size:30px;font-weight:700;color:var(--ground)">' + r[1] + ' negative</span>' +
        '<span class="box mono split-l" style="right:24px;top:30px;font-size:30px;font-weight:700;color:var(--ground)">' + r[2] + ' positive</span></div>'; };
    kit.stage.append(kit.h('<div class="ground"><div class="split-cam" style="position:absolute;inset:0;transform-origin:960px 540px">' +
      '<div class="words" style="left:140px;top:80px;width:1640px;gap:14px"><p class="eyebrow">Coded review mentions</p><h2 class="line md split-line">Getting help is the weak point, not the help itself</h2></div>' +
      ROWS.map(row).join('') +
      '<div class="words" style="left:140px;top:880px;width:1640px"><p class="mono dim split-n" style="font-size:24px">Counts are mentions in the 74 coded reviews; one review can carry several codes.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.split-cam'), line: kit.stage.querySelector('.split-line'), neg: all('.split-neg'), pos: all('.split-pos'), labs: all('.split-l'), ps: all('.split-p'), note: kit.stage.querySelector('.split-n') });
  },
  render(t) {
    W.push(this.cam, t, 12, 1, 1.02);
    TextFx.fadeFromRight(this.line, t, 0.1);
    ROWS.forEach((r, i) => {
      const a = 1.4 + i * 2.6;
      this.neg[i].style.transform = 'scaleX(' + eio(seg(t, a, a + 0.7)) + ')';
      this.pos[i].style.transform = 'scaleX(' + eio(seg(t, a + 0.6, a + 1.3)) + ')';
      this.labs[i * 2].style.opacity = eo(seg(t, a + 0.5, a + 0.8));
      this.labs[i * 2 + 1].style.opacity = eo(seg(t, a + 1.1, a + 1.4));
      const p = eob(seg(t, a + 1.4, a + 1.9), 1.6);
      this.ps[i].style.opacity = Math.min(1, seg(t, a + 1.4, a + 1.5)); this.ps[i].style.transform = 'scale(' + lerp(0.7, 1, p) + ')'; this.ps[i].style.transformOrigin = '100% 100%';
    });
    this.note.style.opacity = eo(seg(t, 7.0, 7.5));
  },
});
