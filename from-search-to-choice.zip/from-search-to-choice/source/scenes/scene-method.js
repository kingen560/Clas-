const { seg, eo, eio, lerp, TextFx } = kit;
const NUMS = [['6', 'mystery-shopping visits', 'Mystery shopping', ''], ['4', 'stores', 'Mystery shopping', ''], ['3', 'observation dates', 'Mystery shopping', ''], ['74', 'Google Maps reviews', 'Secondary data', 'ink']];
kit.scene('method', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="method-cam" style="position:absolute;inset:0;transform-origin:960px 540px">' +
      '<div class="words" style="left:140px;top:96px;width:1640px;gap:14px"><p class="eyebrow">Data collection</p><h2 class="line md method-line">What the findings rest on</h2></div>' +
      W.rail('method-rail', 120, 318, 1680) +
      NUMS.map((n, i) => '<div class="tag ' + n[3] + ' method-t" style="left:' + (140 + i * 420) + 'px;top:346px;width:380px;transform-origin:190px -14px">' +
        '<div style="display:flex;flex-direction:column;gap:6px"><span class="mono" style="font-size:22px;letter-spacing:.08em">' + n[2] + '</span><span class="line num" style="font-size:170px;line-height:.9">' + n[0] + '</span><span class="line sm" style="font-size:44px">' + n[1] + '</span></div></div>').join('') +
      '<div class="words" style="left:140px;top:770px;width:1640px;gap:16px">' +
      '<p class="body method-s">The 6 visits: Torggata ×2 · Stenersgata 2 ×2 · Strømmen Storsenter ×1 · Storo Storsenter ×1</p>' +
      '<p class="body method-s">19 October: 3 visits · 26 October: 2 visits · 3 November: 1 visit. 5 of the 6 began with a documented online search.</p>' +
      '<p class="body dim method-s">No purchases were made.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.method-cam'), line: kit.stage.querySelector('.method-line'), rail: kit.stage.querySelector('.method-rail'), tags: all('.method-t'), ss: all('.method-s') });
  },
  render(t) {
    W.push(this.cam, t, 10, 1, 1.025);
    TextFx.fadeFromRight(this.line, t, 0.1);
    this.rail.style.transform = 'scaleX(' + eo(seg(t, 0.3, 0.9)) + ')';
    this.tags.forEach((el, i) => W.hang(el, t, 0.9 + i * 0.5, i, 110));
    this.ss.forEach((el, i) => { const a = eo(seg(t, 3.4 + i * 0.6, 3.9 + i * 0.6)); el.style.opacity = a; el.style.transform = 'translateX(' + lerp(26, 0, a) + 'px)'; });
  },
});
