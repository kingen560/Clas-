const { seg, eo, eio, eob, lerp } = kit;
const STORES = [['Torggata', 35, '3.7'], ['Oslo City (Stenersgata 1)', 39, '4.0']];
kit.scene('reviews', {
  init(kit) {
    const W0 = 1640, w1 = Math.round(W0 * 35 / 74);
    let dots = '';
    for (let i = 0; i < 74; i++) dots += '<div class="reviews-d" style="position:absolute;left:' + ((i % 37) * 44) + 'px;top:' + (Math.floor(i / 37) * 46) + 'px;width:30px;height:30px;border-radius:50%;background:' + (i < 21 ? 'var(--main)' : 'var(--rail)') + '"></div>';
    kit.stage.append(kit.h('<div class="ground"><div class="reviews-cam" style="position:absolute;inset:0;transform-origin:960px 540px">' +
      '<div class="box" style="left:140px;top:70px;display:flex;align-items:flex-end;gap:30px"><span class="line num gold reviews-n" style="font-size:190px;line-height:.85">74</span>' +
      '<div class="words" style="position:relative;gap:8px;padding-bottom:10px"><p class="eyebrow">Secondary research</p><p class="line md">Google Maps reviews</p><p class="mono dim" style="font-size:24px">Collected 26 October 2026</p></div></div>' +
      '<div class="box" style="left:140px;top:340px;width:' + W0 + 'px;height:110px;border-radius:10px;overflow:hidden;background:color-mix(in srgb, var(--second) 8%, transparent)">' +
      '<div class="box reviews-b" style="left:0;top:0;width:' + (w1 - 4) + 'px;height:110px;background:var(--second);transform-origin:0 50%"></div>' +
      '<div class="box reviews-b" style="left:' + w1 + 'px;top:0;width:' + (W0 - w1) + 'px;height:110px;background:color-mix(in srgb, var(--second) 72%, var(--ground));transform-origin:0 50%"></div>' +
      STORES.map((s, i) => '<div class="box reviews-l" style="left:' + (i ? w1 + 28 : 28) + 'px;top:16px;color:var(--ground);display:flex;flex-direction:column;gap:4px"><span class="line sm" style="font-size:44px">' + s[0] + ': ' + s[1] + ' reviews</span><span class="mono" style="font-size:22px">Average ' + s[2] + ' / 5 in the sample</span></div>').join('') + '</div>' +
      '<div class="box mono dim" style="left:140px;top:470px;font-size:24px">Combined sample average: 3.9 / 5</div>' +
      '<div class="box" style="left:140px;top:580px;width:1640px;height:92px">' + dots + '</div>' +
      '<div class="words" style="left:140px;top:700px;width:1640px;gap:10px"><p class="line sm reviews-r">21 of 74 were posted within about a year of collection</p></div>' +
      '<div class="words" style="left:140px;top:850px;width:1500px"><p class="sub reviews-c">A keyword-based selection, not a random sample. Every percentage in this film describes the coded reviews only, not all Clas Ohlson customers.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.reviews-cam'), n: kit.stage.querySelector('.reviews-n'), bars: all('.reviews-b'), labs: all('.reviews-l'), dots: all('.reviews-d'), r: kit.stage.querySelector('.reviews-r'), c: kit.stage.querySelector('.reviews-c') });
  },
  render(t) {
    W.push(this.cam, t, 12, 1, 1.02);
    const v = String(Math.round(lerp(37, 74, eo(seg(t, 0, 1.2)))));
    if (this.n.textContent !== v) this.n.textContent = v;
    this.bars.forEach((el, i) => { el.style.transform = 'scaleX(' + eio(seg(t, 1.2 + i * 0.6, 1.9 + i * 0.6)) + ')'; });
    this.labs.forEach((el, i) => { el.style.opacity = eo(seg(t, 1.8 + i * 0.6, 2.3 + i * 0.6)); });
    this.dots.forEach((el, i) => { const a = 3.6 + i * 0.02, p = eob(seg(t, a, a + 0.3), 1.8); el.style.transform = 'scale(' + p + ')'; });
    const r = eo(seg(t, 5.4, 5.9));
    this.r.style.opacity = r; this.r.style.transform = 'translateX(' + lerp(26, 0, r) + 'px)';
    const c = eo(seg(t, 6.8, 7.4));
    this.c.style.opacity = c; this.c.style.transform = 'translateX(' + lerp(26, 0, c) + 'px)';
  },
});
