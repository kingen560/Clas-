const { seg, eo, eio, eob, lerp, clamp01, TextFx } = kit;
const V = [
  ['MS5 · 26 Oct · 15:34–15:42', 'Stenersgata 2', 'Space heaters and lamps · online: Mill SG2000MEC, NOK 699', 'Waited about 3 minutes. Vague answers on suitability, popularity and differences. Unsure where football pumps were.', 3, 3, false, 'No suitable heater found'],
  ['MS3 · 26 Oct · about 16:00', 'Torggata', 'Computing and multimedia · no online search documented', 'Busy store. One employee, at the information desk. Asked to come back in a few hours or the next day.', 0, 0, false, 'Not resolved'],
  ['MS6 · 3 Nov · 14:26–14:35', 'Storo Storsenter', 'Electric toothbrushes · online: Oral-B iO 2, NOK 499', 'Waited about 3 minutes, then asked. Models, brush heads and the included charger explained.', 2, 4, true, 'Product found']
];
kit.scene('later', {
  init(kit) {
    const meter = v => !v[4] ? '' : '<div style="display:flex;flex-direction:column;gap:8px"><span class="mono" style="font-size:22px">Feeling score, 1–5</span><div style="display:flex;gap:8px;align-items:center">' + [0, 1, 2, 3, 4].map(() => '<div class="later-seg" style="width:44px;height:28px;border-radius:5px;box-sizing:border-box;border:3px solid var(--ground)"></div>').join('') + '<span class="line later-n" style="font-size:46px;margin-left:12px"></span></div></div>';
    kit.stage.append(kit.h('<div class="ground"><div class="later-cam" style="position:absolute;inset:0;transform-origin:960px 600px">' + W.dates('later-dates', [1, 2]) +
      '<div class="words" style="left:140px;top:190px;width:1640px"><h2 class="line md later-line">26 October and 3 November: three more visits</h2></div>' +
      W.rail('later-rail', 120, 316, 1680) +
      V.map((v, i) => '<div class="tag ink later-c" style="left:' + (140 + i * 560) + 'px;top:342px;width:520px;transform-origin:260px -14px">' +
        '<div style="display:flex;flex-direction:column;gap:13px"><span class="mono" style="font-size:24px">' + v[0] + '</span>' +
        '<span class="line sm" style="font-size:58px">' + v[1] + '</span><span class="mono" style="font-size:21px;line-height:1.35">' + v[2] + '</span>' +
        '<span style="font-size:28px;line-height:1.3">' + v[3] + '</span>' + meter(v) + W.stamp('later-st', v[6], v[7]) + '</div></div>').join('') +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.later-cam'), dates: kit.stage.querySelector('.later-dates'), line: kit.stage.querySelector('.later-line'), rail: kit.stage.querySelector('.later-rail'), cards: all('.later-c'), sts: all('.later-st'), segs: all('.later-seg'), ns: all('.later-n') });
  },
  render(t) {
    W.push(this.cam, t, 20, 1, 1.02);
    this.dates.style.opacity = eo(seg(t, 0, 0.5));
    TextFx.fadeFromRight(this.line, t, 0.3);
    this.rail.style.transform = 'scaleX(' + eo(seg(t, 0.6, 1.2)) + ')';
    let m = 0;
    V.forEach((v, i) => {
      const a = 1.4 + i * 4.0;
      W.hang(this.cards[i], t, a, i, 120);
      if (v[4]) {
        const s0 = a + 2.4, lvl = t < s0 + 0.8 ? v[4] * eo(seg(t, s0, s0 + 0.6)) : v[4] + (v[5] - v[4]) * eob(seg(t, s0 + 0.8, s0 + 1.3), 1.5);
        for (let k = 0; k < 5; k++) { const f = clamp01(lvl - k); this.segs[m * 5 + k].style.background = 'linear-gradient(90deg, ' + (v[6] ? 'var(--ground)' : 'var(--accent)') + ' ' + (f * 100) + '%, transparent 0)'; }
        const txt = t < s0 + 0.8 ? String(v[4]) : v[4] + ' → ' + v[5];
        if (this.ns[m].textContent !== txt) this.ns[m].textContent = txt;
        m++;
      }
      const s = a + 3.4, p = eob(seg(t, s, s + 0.4), 1.9);
      this.sts[i].style.opacity = Math.min(1, seg(t, s, s + 0.08));
      this.sts[i].style.transform = 'scale(' + lerp(1.7, 1, p) + ') rotate(' + lerp(-12, -3, p) + 'deg)';
    });
  },
});
