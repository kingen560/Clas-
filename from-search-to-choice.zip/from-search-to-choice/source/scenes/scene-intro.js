const { seg, eo, eio, eob, lerp } = kit;
kit.scene('intro', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="intro-cam" style="position:absolute;inset:0;transform-origin:960px 420px">' +
      W.sign('intro-hang', 960, 150, 1440, 260, 112, 'From product search to informed choice') +
      '<div class="words" style="left:260px;top:520px;width:1400px;align-items:center;text-align:center;gap:26px">' +
      '<p class="eyebrow intro-eye">Clas Ohlson · Customer experience audit</p>' +
      '<p class="intro-q" style="font-size:40px;line-height:1.38">How does access to product information and employee assistance shape customers’ ability to make informed product choices across Clas Ohlson’s online and in-store customer journey?</p>' +
      '<p class="mono dim intro-c" style="font-size:24px">MST 0220 Customer Experience Management · BI · 2026</p></div>' +
      '</div><div class="edge"></div></div>'));
    const q = s => kit.stage.querySelector(s);
    Object.assign(this, { cam: q('.intro-cam'), hang: q('.intro-hang'), eye: q('.intro-eye'), qn: q('.intro-q'), c: q('.intro-c') });
  },
  render(t) {
    W.push(this.cam, t, 10, 1, 1.03);
    const drop = eob(seg(t, -1.0, -0.15), 1.5);
    const sw = 1.8 * Math.exp(-Math.max(0, t + 0.15) * 0.8) * Math.sin((t + 0.15) * 3) + 0.3 * Math.sin(t * 1.4);
    this.hang.style.transform = 'translateY(' + lerp(-700, 0, drop) + 'px) rotate(' + (sw * 0.5).toFixed(2) + 'deg)';
    this.eye.style.opacity = 1;
    const a = eo(seg(t, 1.0, 1.8));
    this.qn.style.opacity = a; this.qn.style.transform = 'translateY(' + lerp(26, 0, a) + 'px)';
    const c = eo(seg(t, 2.2, 2.8));
    this.c.style.opacity = c;
  },
});
