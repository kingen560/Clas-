const { seg, eo, eio, eob, lerp, TextFx } = kit;
const V = [
  ['MS1 · 12:15–12:35', 'Torggata', 'Wi-Fi routers and lamps', 'About 10 minutes trying to get attention. No one approached.', false, 'Left without help', ''],
  ['MS2 · 12:40–12:55', 'Stenersgata 2', 'Wi-Fi routers and lamps', 'Asked for help after about 3 minutes. Options explained; same router as found online.', true, 'Router found', 'Lamp question unresolved'],
  ['MS4 · 16:58–17:17', 'Strømmen Storsenter', 'Mouse traps', 'Helped about a minute after asking. Differences, use and placement explained.', true, 'Product found', '']
];
kit.scene('day-one', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="day-one-cam" style="position:absolute;inset:0;transform-origin:960px 600px">' + W.dates('day-one-dates', [0]) +
      '<div class="words" style="left:140px;top:190px;width:1640px"><h2 class="line md day-one-line">19 October: three visits in one afternoon</h2></div>' +
      W.rail('day-one-rail', 120, 316, 1680) +
      V.map((v, i) => '<div class="tag ink day-one-c" style="left:' + (140 + i * 560) + 'px;top:342px;width:520px;transform-origin:260px -14px">' +
        '<div style="display:flex;flex-direction:column;gap:14px"><span class="mono" style="font-size:26px">' + v[0] + '</span>' +
        '<span class="line sm" style="font-size:62px">' + v[1] + '</span><span class="mono" style="font-size:24px;letter-spacing:.04em">' + v[2] + '</span>' +
        '<span style="font-size:31px;line-height:1.3">' + v[3] + '</span>' + W.stamp('day-one-st', v[4], v[5]) +
        (v[6] ? '<span class="mono" style="font-size:24px">' + v[6] + '</span>' : '') + '</div></div>').join('') +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.day-one-cam'), dates: kit.stage.querySelector('.day-one-dates'), line: kit.stage.querySelector('.day-one-line'), rail: kit.stage.querySelector('.day-one-rail'), cards: all('.day-one-c'), sts: all('.day-one-st') });
  },
  render(t) {
    W.push(this.cam, t, 16, 1, 1.02);
    this.dates.style.opacity = eo(seg(t, 0, 0.5));
    TextFx.fadeFromRight(this.line, t, 0.3);
    this.rail.style.transform = 'scaleX(' + eo(seg(t, 0.6, 1.2)) + ')';
    this.cards.forEach((el, i) => W.hang(el, t, 1.4 + i * 3.2, i, 120));
    this.sts.forEach((el, i) => {
      const a = 1.4 + i * 3.2 + 1.6, p = eob(seg(t, a, a + 0.4), 1.9);
      el.style.opacity = Math.min(1, seg(t, a, a + 0.08));
      el.style.transform = 'scale(' + lerp(1.7, 1, p) + ') rotate(' + lerp(-12, -3, p) + 'deg)';
    });
  },
});
