const { seg, eo, eio, eob, lerp, TextFx } = kit;
const OK = [['Stenersgata 2', 'MS2 · 19 Oct', 'Wi-Fi router', 1], ['Strømmen Storsenter', 'MS4 · 19 Oct', 'Mousetrap', 0], ['Storo Storsenter', 'MS6 · 3 Nov', 'Electric toothbrush', 0]];
const NO = [['Torggata', 'MS1 · 19 Oct, 12:15', 'No assistance', 0], ['Torggata', 'MS3 · 26 Oct, 16:00', 'Asked to return later', 0], ['Stenersgata 2', 'MS5 · 26 Oct', 'Advice too vague', 1]];
kit.scene('outcomes', {
  init(kit) {
    const tag = (v, x, row, cls) => '<div class="tag ' + cls + ' outcomes-t" data-st="' + v[3] + '" style="left:' + x + 'px;top:' + (360 + row * 128) + 'px;width:780px;display:flex;align-items:center;gap:20px;padding:16px 50px 16px 26px;transform-origin:390px -14px">' +
      '<div style="display:flex;flex-direction:column;gap:2px;width:400px"><span class="line sm" style="font-size:44px">' + v[0] + '</span><span class="mono" style="font-size:22px">' + v[1] + '</span></div><span style="font-size:32px;font-weight:600">' + v[2] + '</span></div>';
    kit.stage.append(kit.h('<div class="ground"><div class="outcomes-cam" style="position:absolute;inset:0;transform-origin:960px 520px">' +
      '<div class="words outcomes-h" style="left:140px;top:90px;width:780px;gap:4px"><span class="line num gold" style="font-size:150px;line-height:.9">3</span><p class="line sm">visits where a suitable product was identified</p></div>' +
      '<div class="words outcomes-h" style="left:1000px;top:90px;width:780px;gap:4px"><span class="line num hot" style="font-size:150px;line-height:.9">3</span><p class="line sm">visits where none was identified</p></div>' +
      [0, 1, 2].map(r => W.rail('outcomes-rail', 120, 340 + r * 128, 1680)).join('') +
      OK.map((v, i) => tag(v, 140, i, '')).join('') + NO.map((v, i) => tag(v, 1000, i, 'hot')).join('') +
      '<div class="words" style="left:140px;top:770px;width:1500px;gap:16px"><p class="line sm outcomes-a">Stenersgata 2 appears on both sides.</p>' +
      '<p class="sub outcomes-b">On 19 October the router was found but the lamp question stayed open, so a single visit can hold both a good and a poor touchpoint.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.outcomes-cam'), hs: all('.outcomes-h'), rails: all('.outcomes-rail'), tags: all('.outcomes-t'), a: kit.stage.querySelector('.outcomes-a'), b: kit.stage.querySelector('.outcomes-b') });
  },
  render(t) {
    W.push(this.cam, t, 13, 1, 1.02);
    this.hs.forEach((el, i) => { const p = eo(seg(t, 0.1 + i * 2.0, 0.6 + i * 2.0)); el.style.opacity = p; el.style.transform = 'translateY(' + lerp(20, 0, p) + 'px)'; });
    this.rails.forEach((el, i) => { el.style.transform = 'scaleX(' + eo(seg(t, 0.4 + i * 0.15, 1.0 + i * 0.15)) + ')'; });
    this.tags.forEach((el, i) => {
      W.hang(el, t, (i < 3 ? 0.9 : 2.9) + (i % 3) * 0.45, i, 80);
      const hi = el.dataset.st === '1' ? eo(seg(t, 5.6, 6.1)) : 0;
      el.style.outline = hi > 0 ? (6 * hi).toFixed(1) + 'px solid var(--second)' : 'none';
      el.style.outlineOffset = '6px';
    });
    TextFx.fadeFromRight(this.a, t, 5.7);
    const b = eo(seg(t, 6.6, 7.2));
    this.b.style.opacity = b; this.b.style.transform = 'translateX(' + lerp(26, 0, b) + 'px)';
  },
});
