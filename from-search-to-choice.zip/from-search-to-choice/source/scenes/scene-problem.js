const { seg, eo, eio, eob, lerp, TextFx } = kit;
const GA = 780, GB = 1290, END = 1700, X0 = 140, TW = 300;
const TK = [['MS1 · Torggata 12:15', GA], ['MS3 · Torggata 16:00', GA], ['MS5 · Stenersgata 2', GB], ['MS2 · Stenersgata 2', END], ['MS4 · Strømmen', END], ['MS6 · Storo', END]];
kit.scene('problem', {
  init(kit) {
    const gate = (x, letter, label, q, cls) => '<div class="box ' + cls + '" style="left:' + (x - 6) + 'px;top:330px;width:12px;height:440px;border-radius:6px;background:var(--second)"></div>' +
      '<div class="sign ' + cls + '" style="left:' + (x - 230) + 'px;top:170px;width:460px;min-height:140px;flex-direction:column;gap:6px;padding:14px 22px"><span class="mono" style="font-size:22px">' + letter + ' · ' + label + '</span><span style="font-size:46px">' + q + '</span></div>';
    kit.stage.append(kit.h('<div class="ground"><div class="problem-cam" style="position:absolute;inset:0;transform-origin:960px 520px">' +
      '<div class="words" style="left:140px;top:70px;width:600px"><p class="eyebrow">The customer experience problem</p></div>' +
      TK.map((k, i) => '<div class="box" style="left:' + X0 + 'px;top:' + (366 + i * 66) + 'px;width:' + (END - X0 + 60) + 'px;height:4px;background:color-mix(in srgb, var(--second) 12%, transparent)"></div>').join('') +
      gate(GA, 'A', 'Accessibility', 'Can I get help?', 'problem-ga') + gate(GB, 'B', 'Advice quality', 'Can the advice help me choose?', 'problem-gb') +
      '<div class="box problem-end" style="left:' + (END + 40) + 'px;top:330px;width:8px;height:440px;border-radius:4px;background:var(--main)"></div>' +
      '<div class="tag problem-end" style="left:' + (END - 160) + 'px;top:200px;padding:12px 44px 12px 18px"><span class="line sm" style="font-size:36px">Informed choice</span></div>' +
      TK.map((k, i) => '<div class="tag ink problem-t" style="left:0;top:' + (346 + i * 66) + 'px;width:' + TW + 'px;padding:8px 14px;border-radius:6px;box-shadow:none"><span class="mono" style="font-size:22px;font-weight:700">' + k[0] + '</span></div>').join('') +
      '<div class="words" style="left:140px;top:810px;width:1560px;gap:14px"><p class="line sm problem-a">Customers need help to judge whether a product suits them, but the journey does not consistently ensure that support.</p>' +
      '<p class="sub problem-b">Each gate can fail on its own: two visits stopped at A, one got through A and stopped at B.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.problem-cam'), ga: all('.problem-ga'), gb: all('.problem-gb'), end: all('.problem-end'), tks: all('.problem-t'), a: kit.stage.querySelector('.problem-a'), b: kit.stage.querySelector('.problem-b') });
  },
  render(t) {
    W.push(this.cam, t, 15, 1, 1.02);
    this.ga.forEach(el => { const p = eob(seg(t, 0.4, 0.9), 1.6); el.style.opacity = Math.min(1, seg(t, 0.4, 0.5)); el.style.transform = 'translateY(' + lerp(-60, 0, p) + 'px)'; });
    this.gb.forEach(el => { const p = eob(seg(t, 1.0, 1.5), 1.6); el.style.opacity = Math.min(1, seg(t, 1.0, 1.1)); el.style.transform = 'translateY(' + lerp(-60, 0, p) + 'px)'; });
    this.end.forEach(el => { el.style.opacity = eo(seg(t, 1.5, 2.0)); });
    this.tks.forEach((el, i) => {
      const stop = TK[i][1] - (TK[i][1] === END ? TW - 30 : TW + 20), a = 2.4 + i * 0.25;
      const arr = a + 2.4 * (stop - X0) / (END - X0) + 0.6, go = eio(seg(t, a, arr));
      const arrived = t >= arr, failed = TK[i][1] !== END;
      const shake = arrived && failed ? 10 * Math.sin((t - arr) * 16) * Math.exp(-(t - arr) * 2.5) : 0;
      el.style.opacity = Math.min(1, seg(t, a - 0.3, a));
      el.style.transform = 'translateX(' + (lerp(X0, stop, go) + shake) + 'px)';
      el.style.background = arrived ? (failed ? 'var(--accent)' : 'var(--main)') : 'var(--second)';
    });
    TextFx.fadeFromRight(this.a, t, 6.6);
    const b = eo(seg(t, 8.4, 9.0));
    this.b.style.opacity = b; this.b.style.transform = 'translateX(' + lerp(26, 0, b) + 'px)';
  },
});
