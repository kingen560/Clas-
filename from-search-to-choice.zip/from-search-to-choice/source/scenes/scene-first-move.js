const { seg, eo, eio, eob, lerp, TextFx } = kit;
const R = [
  ['MS1 · 19 Oct · 12:15', 'Torggata', false, 'About 10 min, no help'],
  ['MS2 · 19 Oct · 12:40', 'Stenersgata 2', true, 'About 3 min, then asked'],
  ['MS4 · 19 Oct · 16:58', 'Strømmen Storsenter', true, '1 min 12 s after asking'],
  ['MS5 · 26 Oct · 15:34', 'Stenersgata 2', true, 'About 3 min'],
  ['MS3 · 26 Oct · 16:00', 'Torggata', true, 'Not recorded'],
  ['MS6 · 3 Nov · 14:26', 'Storo Storsenter', true, 'About 3 min']
];
kit.scene('first-move', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="first-move-cam" style="position:absolute;inset:0;transform-origin:960px 520px">' +
      '<div class="words" style="left:140px;top:80px;width:1640px;gap:14px"><p class="eyebrow">Who made the first move?</p><h2 class="line md first-move-line">An employee approached first in 0 of 6 visits.</h2></div>' +
      '<div class="box mono dim" style="left:140px;top:262px;width:1640px;display:flex;font-size:22px;letter-spacing:.1em"><span style="width:740px">VISIT</span><span style="width:400px">FIRST CONTACT</span><span>RECORDED WAIT</span></div>' +
      R.map((r, i) => '<div class="box first-move-r" style="left:140px;top:' + (306 + i * 100) + 'px;width:1640px;height:86px;display:flex;align-items:center;border-bottom:2px solid color-mix(in srgb, var(--second) 14%, transparent)">' +
        '<span class="mono" style="width:340px;font-size:24px">' + r[0] + '</span><span class="line sm" style="width:400px;font-size:42px">' + r[1] + '</span>' +
        '<span style="width:400px"><span class="chip" style="font-size:24px;color:' + (r[2] ? 'var(--main)' : 'var(--accent)') + '">' + (r[2] ? 'Customer asked' : 'No contact at all') + '</span></span>' +
        '<span style="font-size:30px">' + r[3] + '</span></div>').join('') +
      '<div class="words" style="left:140px;top:930px;width:1640px"><p class="mono dim first-move-note" style="font-size:22px">Waits as recorded by the shoppers; most are estimates. The Strømmen wait runs from the request to the start of help.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.first-move-cam'), line: kit.stage.querySelector('.first-move-line'), rows: all('.first-move-r'), note: kit.stage.querySelector('.first-move-note') });
  },
  render(t) {
    W.push(this.cam, t, 13, 1, 1.02);
    this.rows.forEach((el, i) => { const a = 0.3 + i * 0.55, p = eo(seg(t, a, a + 0.5)); el.style.opacity = p; el.style.transform = 'translateX(' + lerp(60, 0, p) + 'px)'; });
    this.line.style.opacity = t < 3.6 ? 0 : 1;
    TextFx.fadeFromRight(this.line, t, 3.7);
    const n = eo(seg(t, 5.2, 5.8));
    this.note.style.opacity = n;
  },
});
