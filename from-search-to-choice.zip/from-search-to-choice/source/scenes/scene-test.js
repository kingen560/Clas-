const { seg, eo, eio, eob, lerp, TextFx } = kit;
const M = ['Waiting time for help', 'Completed handovers', 'Unresolved questions', 'Recommendation accuracy', 'Understanding of the product choice'];
kit.scene('test', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="test-cam" style="position:absolute;inset:0;transform-origin:960px 560px">' +
      '<div class="words" style="left:140px;top:120px;width:1640px;gap:18px"><p class="eyebrow">Evaluation</p><h2 class="line md test-line">Test it before rolling it out</h2>' +
      '<p class="sub test-sub">Pilot the improvements in selected stores and track five measures.</p></div>' +
      W.rail('test-rail', 120, 452, 1680) +
      M.map((m, i) => '<div class="tag ink test-t" style="left:' + (140 + i * 332) + 'px;top:478px;width:312px;min-height:250px;transform-origin:156px -14px"><div style="display:flex;flex-direction:column;gap:14px"><span class="mono" style="font-size:24px">0' + (i + 1) + '</span><span class="line sm" style="font-size:46px">' + m + '</span></div></div>').join('') +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.test-cam'), line: kit.stage.querySelector('.test-line'), sub: kit.stage.querySelector('.test-sub'), rail: kit.stage.querySelector('.test-rail'), tags: all('.test-t') });
  },
  render(t) {
    W.push(this.cam, t, 10, 1, 1.025);
    TextFx.fadeFromRight(this.line, t, 0.1);
    const s = eo(seg(t, 1.0, 1.5));
    this.sub.style.opacity = s; this.sub.style.transform = 'translateX(' + lerp(26, 0, s) + 'px)';
    this.rail.style.transform = 'scaleX(' + eo(seg(t, 1.4, 2.0)) + ')';
    this.tags.forEach((el, i) => W.hang(el, t, 2.0 + i * 0.5, i, 100));
  },
});
