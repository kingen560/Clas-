const { seg, eo, eio, eob, lerp, TextFx } = kit;
const FX = [
  ['1', 'Make help easier to reach', ['Human'], ['Clearer service signage and routes to help', 'A brief acknowledgement of customers who wait', 'Clear roles for answering requests, coordinated with checkout and restocking'], ''],
  ['2', 'Connect customers with expertise', ['Human'], ['Hand over to a knowledgeable colleague, or explain the next step', 'Ask about use, budget, performance and compatibility', 'Explain why a product fits, not only where it is'], ''],
  ['3', 'Better information at the point of choice', ['Physical', 'Digital', 'AI'], ['Check shelf labels and product placement', 'Comparisons that match online and in store, accessories included', 'AI support as an aid to staff, not a replacement'], 'ink']
];
kit.scene('fixes', {
  init(kit) {
    const chip = c => '<span class="chip" style="' + (c === 'AI' ? 'background:var(--accent);border-color:var(--accent);color:var(--ground)' : '') + '">' + c + '</span>';
    kit.stage.append(kit.h('<div class="ground"><div class="fixes-cam" style="position:absolute;inset:0;transform-origin:960px 560px">' +
      '<div class="words" style="left:140px;top:80px;width:1640px;gap:14px"><p class="eyebrow">Recommendations · proposed, not yet tested</p><h2 class="line md fixes-line">Three improvements</h2></div>' +
      W.rail('fixes-rail', 120, 272, 1680) +
      FX.map((f, i) => '<div class="tag ' + f[4] + ' fixes-c" style="left:' + (140 + i * 560) + 'px;top:298px;width:520px;min-height:640px;transform-origin:260px -14px">' +
        '<div style="display:flex;flex-direction:column;gap:16px"><div style="display:flex;gap:10px">' + f[2].map(chip).join('') + '</div>' +
        '<span class="line" style="font-size:62px;line-height:1">' + f[1] + '</span>' +
        f[3].map(b => '<div class="fixes-b" style="display:flex;gap:14px;align-items:flex-start;font-size:29px;line-height:1.3"><span style="flex:none;width:12px;height:12px;margin-top:13px;border-radius:2px;background:var(--ground)"></span><span>' + b + '</span></div>').join('') + '</div></div>').join('') +
      '</div><div class="edge"></div></div>'));
    const all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: kit.stage.querySelector('.fixes-cam'), line: kit.stage.querySelector('.fixes-line'), rail: kit.stage.querySelector('.fixes-rail'), cards: all('.fixes-c'), bs: all('.fixes-b') });
  },
  render(t) {
    W.push(this.cam, t, 19, 1, 1.02);
    TextFx.fadeFromRight(this.line, t, 0.1);
    this.rail.style.transform = 'scaleX(' + eo(seg(t, 0.3, 0.9)) + ')';
    this.cards.forEach((el, i) => W.hang(el, t, 1.0 + i * 3.6, i, 120));
    this.bs.forEach((el, k) => { const i = Math.floor(k / 3), a = 1.0 + i * 3.6 + 0.9 + (k % 3) * 0.6, p = eo(seg(t, a, a + 0.45)); el.style.opacity = p; el.style.transform = 'translateX(' + lerp(20, 0, p) + 'px)'; });
  },
});
