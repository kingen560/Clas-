const { seg, eo, eio, eob, lerp, clamp01, TextFx } = kit;
const STEPS = ['Search online', 'Check stock and shelf', 'Find the product', 'Get help', 'Understand the right choice'];
const NX = i => 290 + i * 335, PY = 600;
const T_NODE = [2.6, 3.3, 4.0, 4.7, 4.7];
kit.scene('journey', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="journey-cam" style="position:absolute;inset:0;transform-origin:960px 560px">' +
      '<div class="words" style="left:140px;top:80px;width:1640px;gap:14px"><p class="eyebrow">Scope</p><h2 class="line md journey-line">The journey we audited</h2></div>' +
      '<div class="box journey-band" style="left:140px;top:262px;width:640px;border-top:4px solid var(--main);padding-top:10px"><span class="mono gold" style="font-size:24px;letter-spacing:.12em">ONLINE</span></div>' +
      '<div class="box journey-band" style="left:810px;top:262px;width:970px;border-top:4px solid var(--second);padding-top:10px"><span class="mono" style="font-size:24px;letter-spacing:.12em">IN THE STORE</span></div>' +
      STEPS.map((s, i) => '<div class="sign journey-s" style="left:' + (NX(i) - 150) + 'px;top:340px;width:300px;min-height:150px;flex-direction:column;gap:8px;padding:16px 18px;transform-origin:150px -20px' + (i < 2 ? ';background:var(--main)' : '') + '"><span class="mono" style="font-size:22px">' + (i + 1) + '</span><span style="font-size:44px">' + s + '</span></div>').join('') +
      '<div class="box" style="left:' + NX(0) + 'px;top:' + (PY - 3) + 'px;width:' + (NX(4) - NX(0)) + 'px;height:6px;border-radius:3px;background:var(--rail)"></div>' +
      STEPS.map((s, i) => '<div class="box journey-n" style="left:' + (NX(i) - 18) + 'px;top:' + (PY - 18) + 'px;width:36px;height:36px;border-radius:50%;background:var(--ground);border:6px solid var(--rail)"></div>').join('') +
      '<div class="box journey-m" style="left:-26px;top:' + (PY - 26) + 'px;width:52px;height:52px;border-radius:50%;background:var(--main);box-shadow:0 0 0 10px color-mix(in srgb, var(--main) 25%, transparent)"></div>' +
      '<div class="tag hot journey-brk" style="left:' + (NX(3) - 60) + 'px;top:' + (PY + 50) + 'px;padding:12px 50px 12px 20px"><span class="line sm" style="font-size:38px">Where the journey breaks</span></div>' +
      '<div class="words" style="left:140px;top:790px;width:1300px;gap:16px"><p class="line sm journey-a">Finding a product is not the same as choosing the right one.</p>' +
      '<p class="sub journey-b">Online stock and shelf information helped customers find products. Customers with little product knowledge still needed someone to explain performance, compatibility and fit.</p></div>' +
      '</div><div class="edge"></div></div>'));
    const q = s => kit.stage.querySelector(s), all = s => [...kit.stage.querySelectorAll(s)];
    Object.assign(this, { cam: q('.journey-cam'), line: q('.journey-line'), bands: all('.journey-band'), signs: all('.journey-s'), nodes: all('.journey-n'), m: q('.journey-m'), brk: q('.journey-brk'), a: q('.journey-a'), b: q('.journey-b') });
  },
  render(t) {
    W.push(this.cam, t, 12, 1, 1.025);
    TextFx.fadeFromRight(this.line, t, 0.1);
    this.bands.forEach((el, i) => { el.style.opacity = eo(seg(t, 0.6 + i * 0.3, 1.1 + i * 0.3)); });
    this.signs.forEach((el, i) => W.hang(el, t, 1.0 + i * 0.3, i, 70));
    let x = NX(0);
    for (let i = 1; i < 4; i++) x = lerp(x, NX(i), eio(seg(t, T_NODE[i - 1] + 0.15, T_NODE[i])));
    const stall = t > 4.7 ? 10 * Math.sin((t - 4.7) * 5) * Math.exp(-(t - 4.7) * 0.6) : 0;
    this.m.style.opacity = Math.min(1, seg(t, 2.3, 2.6));
    this.m.style.transform = 'translateX(' + (x + stall) + 'px)';
    this.nodes.forEach((el, i) => {
      const reached = i < 3 && t >= T_NODE[i], bad = i >= 3 && t >= 5.0;
      el.style.borderColor = bad ? 'var(--accent)' : reached ? 'var(--main)' : 'var(--rail)';
    });
    this.signs.forEach((el, i) => { if (i >= 3) el.style.background = t >= 5.0 ? 'var(--accent)' : 'var(--second)'; });
    const k = eob(seg(t, 5.1, 5.6), 1.6);
    this.brk.style.opacity = Math.min(1, seg(t, 5.1, 5.2)); this.brk.style.transform = 'scale(' + lerp(0.6, 1, k) + ') rotate(' + lerp(-6, -2, k) + 'deg)';
    TextFx.fadeFromRight(this.a, t, 5.7);
    const b = eo(seg(t, 6.6, 7.2));
    this.b.style.opacity = b; this.b.style.transform = 'translateX(' + lerp(26, 0, b) + 'px)';
  },
});
