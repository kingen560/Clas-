const { seg, eo, eio, eob, lerp, TextFx } = kit;
kit.scene('close', {
  init(kit) {
    kit.stage.append(kit.h('<div class="ground"><div class="close-cam" style="position:absolute;inset:0;transform-origin:960px 420px">' +
      W.sign('close-hang', 960, 150, 1400, 250, 104, 'Finding the product is only the first step.') +
      '<div class="words" style="left:260px;top:500px;width:1400px;align-items:center;text-align:center;gap:26px">' +
      '<p class="line md close-a">Understanding the right choice is what completes the customer experience.</p>' +
      '<div class="close-u" style="width:220px;height:10px;border-radius:5px;background:var(--accent);transform-origin:50% 50%"></div>' +
      '<p class="eyebrow close-b">MST 0220 Customer Experience Management · BI · 2026</p>' +
      '<p class="mono dim close-c" style="font-size:22px;line-height:1.5">Sources: 6 mystery-shopping visits, 19 October – 3 November 2026 · 74 Google Maps reviews, collected 26 October 2026</p></div>' +
      '</div><div class="edge"></div></div>'));
    const q = s => kit.stage.querySelector(s);
    Object.assign(this, { cam: q('.close-cam'), hang: q('.close-hang'), a: q('.close-a'), u: q('.close-u'), b: q('.close-b'), c: q('.close-c') });
  },
  render(t) {
    this.cam.style.transform = 'scale(' + lerp(1.02, 1, eio(seg(t, 0, 11))) + ')';
    const drop = eob(seg(t, 0, 0.8), 1.5);
    const sw = 1.8 * Math.exp(-Math.max(0, t - 0.8) * 0.8) * Math.sin(Math.max(0, t - 0.8) * 3) + 0.3 * Math.sin(t * 1.4);
    this.hang.style.transform = 'translateY(' + lerp(-700, 0, drop) + 'px) rotate(' + (sw * 0.5).toFixed(2) + 'deg)';
    this.hang.style.opacity = Math.min(1, seg(t, 0, 0.1));
    TextFx.fadeFromRight(this.a, t, 1.4);
    this.u.style.transform = 'scaleX(' + eo(seg(t, 2.9, 3.4)) + ')';
    [[this.b, 3.4], [this.c, 3.8]].forEach(([el, k]) => { const e = eo(seg(t, k, k + 0.5)); el.style.opacity = e; el.style.transform = 'translateY(' + lerp(16, 0, e) + 'px)'; });
  },
});
