kit.score(function (S, T) {
  const BPM = 84, B = 60 / BPM;
  S.tempo(BPM, { t0: 0 });
  S.program('pad', 'pad', { rev: 0.6, gain: -3 }); S.program('keys', 'ep', { rev: 0.3, gain: -2 }); S.program('bass', 'bass', { gain: -3 }); S.program('mallet', 'marimba', { rev: 0.3, gain: -4 }); S.program('bell', 'glock', { rev: 0.45, gain: -8 });
  const CH = [['F3', 'A3', 'C4', 'E4'], ['D3', 'F3', 'A3', 'C4'], ['Bb2', 'D3', 'F3', 'A3'], ['C3', 'E3', 'G3', 'Bb3']];
  const RT = ['F2', 'D2', 'Bb1', 'C2'];
  const ids = ['intro', 'method', 'journey', 'day-one', 'later', 'first-move', 'outcomes', 'reviews', 'split', 'lenses', 'problem', 'fixes', 'test', 'sustain', 'close'];
  const drumsIn = { method: 1, reviews: 1, split: 1, fixes: 1 };
  ids.forEach((id, k) => {
    const t0 = T[id], t1 = k < ids.length - 1 ? T[ids[k + 1]] : T.END;
    const c = CH[k % 4];
    S.chord('pad', c, { t: t0, dur: t1 - t0 + 0.3, vel: 30 });
    for (let t = t0; t < t1 - 0.5; t += 4 * B) {
      const half = Math.floor((t - t0) / (8 * B)) % 2;
      S.chord('keys', half ? CH[(k + 2) % 4] : c, { t: t, dur: 3.6 * B, vel: 36 });
      S.note('bass', half ? RT[(k + 2) % 4] : RT[k % 4], { t: t, dur: 1.5 * B, vel: 58 });
    }
    const b0 = Math.ceil((t0 + 0.3) / B), n = Math.max(0, Math.floor(((t1 - 0.3) / B - b0) / 4));
    if (n > 0) {
      S.pattern('mallet', 'x...x.x.', { from: b0, repeat: n, pitch: ['C5', 'A4', 'F5', 'G4'], vel: 34 });
      if (drumsIn[id]) S.drums({ hat: '..o...o.', sidestick: '....x...' }, { from: b0, repeat: n, vel: 30 });
    }
  });
  const pop = (t, v) => S.fx('pop', t, { vel: v || 32 });
  S.fx('thud', 0, { vel: 50 }); S.note('bell', 'C6', { t: 1.0, dur: 1.5, vel: 44 });
  for (let i = 0; i < 4; i++) pop(T.method + 0.9 + i * 0.5 + 0.45, 36);
  for (let i = 0; i < 5; i++) pop(T.journey + 1.0 + i * 0.3 + 0.4, 28);
  S.fx('roll', T.journey + 2.6, { dur: 2.1, vel: 26 }); S.fx('thud', T.journey + 5.0, { vel: 48 });
  for (let i = 0; i < 3; i++) { pop(T['day-one'] + 1.4 + i * 3.2 + 0.45, 36); S.fx('thud', T['day-one'] + 1.4 + i * 3.2 + 1.7, { vel: 44 }); }
  for (let i = 0; i < 3; i++) { const a = T.later + 1.4 + i * 4.0; pop(a + 0.45, 36); if (i !== 1) { S.fx('roll', a + 2.4, { dur: 0.6, vel: 26 }); S.fx('ding', a + 3.25, { vel: 36 }); } S.fx('thud', a + 3.5, { vel: 44 }); }
  for (let i = 0; i < 6; i++) S.fx('tick', T['first-move'] + 0.35 + i * 0.55, { vel: 30 });
  S.note('bass', 'D2', { t: T['first-move'] + 3.7, dur: 2, vel: 70 }); S.note('bell', 'A5', { t: T['first-move'] + 3.7, dur: 1.4, vel: 40 });
  for (let i = 0; i < 3; i++) { pop(T.outcomes + 0.9 + i * 0.45 + 0.45, 34); pop(T.outcomes + 2.9 + i * 0.45 + 0.45, 34); }
  S.fx('ding', T.outcomes + 5.7, { vel: 34 });
  S.fx('roll', T.reviews + 0.05, { dur: 1.1, vel: 24 }); S.fx('whoosh', T.reviews + 1.2, { dur: 1.2, vel: 24 }); S.fx('roll', T.reviews + 3.6, { dur: 1.5, vel: 22 });
  [1.4, 4.0].forEach(a => { S.fx('whoosh', T.split + a, { dur: 1.2, vel: 26 }); S.fx('ding', T.split + a + 1.5, { vel: 38 }); });
  pop(T.problem + 0.6, 34); pop(T.problem + 1.2, 34);
  S.fx('roll', T.problem + 2.4, { dur: 3.5, vel: 20 });
  [3.49, 3.74, 4.78].forEach(a => S.fx('thud', T.problem + a, { vel: 46 }));
  [5.73, 5.98, 6.23].forEach(a => S.fx('ding', T.problem + a, { vel: 32 }));
  for (let i = 0; i < 3; i++) { pop(T.fixes + 1.0 + i * 3.6 + 0.45, 38); for (let j = 0; j < 3; j++) S.fx('tick', T.fixes + 1.0 + i * 3.6 + 0.9 + j * 0.6, { vel: 24 }); }
  for (let i = 0; i < 5; i++) pop(T.test + 2.0 + i * 0.5 + 0.45, 32);
  for (let i = 0; i < 4; i++) pop(T.lenses + 1.2 + i * 3.0 + 0.45, 36);
  S.note('bell', 'E5', { t: T.lenses + 11.6, dur: 1.4, vel: 38 });
  for (let i = 0; i < 3; i++) pop(T.sustain + 1.2 + i * 3.0 + 0.45, 36);
  S.fx('revswell', T.close, { dur: 1.2, vel: 40 }); S.fx('thud', T.close + 0.75, { vel: 50 });
  S.chord('keys', ['F3', 'A3', 'C4', 'E4', 'A4'], { t: T.close + 0.75, dur: 6, vel: 52 }); S.note('bass', 'F2', { t: T.close + 0.75, dur: 5, vel: 66 });
  S.fx('chime', T.close + 3.0, { vel: 44 });
  S.master({ gain: -7, fadeOut: 2.5 });
});
